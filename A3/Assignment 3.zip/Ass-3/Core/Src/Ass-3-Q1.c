/*
 * Ass-3-Q1.c
 *
 *  Created on: Apr 22, 2022
 *      Author: minnieb
 */

#include "Ass-3.h"

#if DO_QUESTION == 1

//Variable to count interrupts
volatile uint32_t IntCount = 0;

//Interrupt call back function (interrupt service routine)
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){

	//check it is the correct pin
	if (GPIO_Pin == joyc_Pin){

		//increment interrupt counter
		IntCount++;
	}
}

void Ass_3_main (void){
	GPIO_PinState JoyState;
	uint32_t IntCountCopy = 0;
	uint32_t IntCountPrevious = 0;
	while(1){

		//read joyc and output to ld6
		JoyState = HAL_GPIO_ReadPin (joyc_GPIO_Port, joyc_Pin);
		HAL_GPIO_WritePin (LD6_GPIO_Port, LD6_Pin, JoyState);

		//Toggle LD3 as a heartbeat
		HAL_GPIO_TogglePin (LD3_GPIO_Port, LD3_Pin);
		HAL_Delay (TOGGLE_DELAY);
		IntCountCopy = IntCount;

		//Check if got an interrupt
		if (IntCountPrevious != IntCountCopy){
			IntCountPrevious = IntCountCopy;
			printf("-> INFO: IntCount = %ld\n", IntCountPrevious);
		}
	}
}

#endif
