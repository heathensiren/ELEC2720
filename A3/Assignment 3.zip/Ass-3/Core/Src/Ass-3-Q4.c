/*
 * Ass-3-Q4.c
 *
 *  Created on: 29 Apr. 2022
 *      Author: minnieb
 */


/* 	- Pushes of the joystick to positions A, D, C, and CTR are detected using interrupts.
	- Pushing the joystick to the A position turns only the green LED on and the rest off.
	- Pushing the joystick to the D position turns only the red LED on and the rest off.
	- Pushing the joystick to the C position turns only the blue LED on and the rest off.
	- Pushing the joystick to the CTR position turns off all LEDs.
	- The LEDs should be controlled solely by DMA. Do not use the HAL_GPIO_WritePin function.
 * */

#include "Ass-3.h"

#if DO_QUESTION == 4

//Initialising callback function
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){

	//Joy A turns green led on
	if (GPIO_Pin == joya_Pin){
		uint greenLed = LD4_Pin;
		uint32_t * p_greenLed = &greenLed;
		HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream0, (uint32_t) p_greenLed, (uint32_t) &(GPIOD->ODR), 1);
	}

	//Joy C turns blue led on
	if (GPIO_Pin == joyc_Pin){
		uint blueLed = LD6_Pin;
		uint32_t * p_blueLed = &blueLed;
		HAL_DMA_Start_IT (&hdma_memtomem_dma2_stream0, (uint32_t) p_blueLed, (uint32_t) &(GPIOD->ODR), 1);
	}

	//Joy D turns red led on
	if (GPIO_Pin == joyd_Pin){
		uint redLed = LD5_Pin;
		uint32_t * p_redLed = &redLed;
		HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream0, (uint32_t) p_redLed, (uint32_t) &(GPIOD->ODR), 1);
	}

	//Joy CTR turns all led off
	if (GPIO_Pin == joyctr_Pin){
		HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream0, (uint32_t) RESET, (uint32_t) &(GPIOD->ODR), 1);
	}

}

//Left empty so CPU bounces calls back
void Ass_3_main (void){
	while(1){

	}
}

#endif
