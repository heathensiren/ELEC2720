/*
 * Ass-3.h
 *
 *  Created on: Apr 22, 2022
 *      Author: minnieb
 */

#ifndef SRC_ASS_3_H_
#define SRC_ASS_3_H_

#include "main.h"

//For printf
#include <stdio.h>

//Question to be completed
#define DO_QUESTION 4

//Parameters
#define TOGGLE_DELAY 100 //Period before toggling heartbeat LED (ms)

//Assignment functions
void Ass_3_main (void);

extern DMA_HandleTypeDef hdma_memtomem_dma2_stream0;

#endif /* SRC_ASS_3_H_ */
