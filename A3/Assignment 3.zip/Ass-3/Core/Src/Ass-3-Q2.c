/*
 * Ass-3-Q2.c
 *
 *  Created on: Apr 22, 2022
 *      Author: minnieb
 */


#include "Ass-3.h"

#if DO_QUESTION == 2

char src[]="*Hello*";

volatile char dst[8]={'A','A','A','A','A','A','A','\0'}; // Ensure NULL terminated

void Ass_3_main (void){
	//Initial value
	printf("BEFORE: dst = '%s'\n", dst);

	//transfer printf above
	HAL_DMA_Start (&hdma_memtomem_dma2_stream0, (uint32_t) src, (uint32_t) dst, 2);
	printf("DMA Transfer initiated. \n");

	//poll for dma completion
	printf("Poll for DMA completion. \n");
	HAL_DMA_PollForTransfer(&hdma_memtomem_dma2_stream0, HAL_DMA_FULL_TRANSFER, HAL_MAX_DELAY);
	printf("DMA complete.\n");

	//print result
	printf("AFTER: dst = '%s' \n", dst);

}

#endif
