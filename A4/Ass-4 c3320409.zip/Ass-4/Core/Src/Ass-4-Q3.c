/*
 * Ass-4-Q3.c
 *
 *  Created on: 29 Apr. 2022
 *      Author: minnieb
 */

#include "Ass-4.h"

#if DO_QUESTION == 3

//Analogue inputs
volatile static uint16_t bar[2];
volatile static uint8_t got_ai = 0;

void Ass_4_main (void){
	HAL_StatusTypeDef status;
	uint32_t i, j;

	while (1){

		//printf("-> Start conversion...\n");
		if ((status = HAL_ADC_Start_DMA(&hadc1, &bar, 2)) != HAL_OK) {
			printf ("-> ERROR: HAL_ADC_Start() call failed (status = %d)\n", status);
		}

		while (got_ai == 0){
		}

		// Loop through both channels to print result
		for (j = 0; j < 2; j++){

			// Print the result as decimal and bar graph
			printf ("Got %4d: |", bar[j]);

			for (i = 0; i < 25; i++){
				if (i <= bar[j] * 25 / 4096){
				printf ("*");
				}

				else{
					printf (" ");
				}
			}
		printf ("| ");
		}
		printf ("\n");

		// Loop delay
		HAL_Delay (500);
	}
}

void HAL_ADC_ConvCpltCallback (ADC_HandleTypeDef *hadc){
	if (hadc == &hadc1) {
		got_ai = 1;
	}
}

#endif
