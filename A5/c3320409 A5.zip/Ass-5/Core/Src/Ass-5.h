/*
 * Ass-5.h
 *
 *  Created on: Apr 22, 2022
 *      Author: minnieb
 */

#ifndef SRC_ASS_5_H_
#define SRC_ASS_5_H_

#include "main.h"

//For printf
#include <stdio.h>

//Question to be completed
#define DO_QUESTION 3

//Parameters
#define TOGGLE_DELAY 100 //Period before toggling heartbeat LED (ms)

//Assignment functions
void Ass_5_main (void);

//extern ADC_HandleTypeDef hadc1;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim2;
extern SPI_HandleTypeDef hspi1;
extern ADC_HandleTypeDef hadc1;

#endif /* SRC_ASS_5_H_ */
