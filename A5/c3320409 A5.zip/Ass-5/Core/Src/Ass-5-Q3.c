/*
 * Ass-5-Q3.c
 *
 *  Created on: 29 Apr. 2022
 *      Author: minnieb
 *
 *      • There are two modes of operation:
			– Mode 1: LED rotates in the clockwise or anti-clockwise direction. Only one LED is lit at any time.
			– Mode 2: Design your own lighting sequence, but you need to distinguish the clockwise and the anticlockwise directions.
 *
 */

#include "Ass-5.h"

#if DO_QUESTION == 3

#define SPI_RD 0x80         // The bit to set SPI to read.

#define DEBOUNCE_INTERVAL 200

static uint16_t LED[] = {LD3_Pin, LD4_Pin, LD6_Pin, LD5_Pin};
static int16_t LEDCounter;
static uint16_t LED2[] = {LD4_Pin, LD5_Pin, LD6_Pin, LD3_Pin};

static uint32_t ADCValue;
uint32_t got_adc;
uint16_t loop = 0;

uint8_t auchSpiTxBuf[2], auchSpiRxBuf[2];

int debounce_counter = 0;
enum debounceState {LOCKED, RELEASED};
enum debounceState debounce_state = RELEASED;
enum modes {mode1, mode2};
enum modes mode = mode1;

GPIO_PinState blueButton;

void Ass_5_main (void){

	HAL_TIM_Base_Start_IT(&htim3);
	HAL_TIM_Base_Start(&htim2);
	HAL_ADC_Start_DMA(&hadc1, &ADCValue, 1);

	// Now set up the MEMS chip for 3.125 Hz sampling rate.
	// Initial setup of the MEMS sample rate
	auchSpiTxBuf[0] = 0x20;   // Control Reg 0x20
	auchSpiTxBuf[1] = 0x11;   // Sampling at 3.125 Hz, X accelerometer

	// Now set the chip select low
	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);

	// Now write the set up data.
	HAL_SPI_Transmit(&hspi1, auchSpiTxBuf, 2, 50);  // Send the set up command.

	//Now set the CS pin high again
	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_SET);

	// We can now read the date back to check that the write was successful
	// Set up the auchSpiTxBuf for a read.
	auchSpiTxBuf[0] = 0x20 | SPI_RD;   // Control Reg 0x20 to be read

	// Now set the chip select low
	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);

	// Now write the address.
	HAL_SPI_Transmit(&hspi1, auchSpiTxBuf, 1, 50);

	// Now Read the data
	HAL_SPI_Receive(&hspi1, auchSpiRxBuf, 1, 50);

	// Now set the CS pin high again
	HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_SET);

	// Now print out the value to see if it is correct
	//printf("Control value read = 0x%x\n", auchSpiRxBuf[0]);

	while(1){

		// Set up the auchSpiTxBuf for a read.
		auchSpiTxBuf[0] = 0x29 | SPI_RD;   // Control Reg 0x29 X value to be read

		// Now set the chip select low
		HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);

		// Now write the address.
		HAL_SPI_Transmit(&hspi1, auchSpiTxBuf, 1, 50);

		// Now Read the data
		HAL_SPI_Receive(&hspi1, auchSpiRxBuf, 1, 50);

		//Now set the CS pin high again
		HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_SET);
		HAL_Delay(200);

		// Now print out the value to see if it is correct
		//printf("Value read = %d\n", (int8_t)auchSpiRxBuf[0]);

		switch(debounce_state) {
			  case RELEASED:
				  blueButton = HAL_GPIO_ReadPin (blue_GPIO_Port, blue_Pin);

				  if(blueButton == 1){
					  HAL_GPIO_WritePin (LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);
					  HAL_GPIO_WritePin (LD4_GPIO_Port, LD4_Pin, GPIO_PIN_RESET);
					  HAL_GPIO_WritePin (LD5_GPIO_Port, LD5_Pin, GPIO_PIN_RESET);
					  HAL_GPIO_WritePin (LD6_GPIO_Port, LD6_Pin, GPIO_PIN_RESET);
					  switch(mode){

					  case mode1:
						  mode = mode2;
						  break;

					  case mode2:
						  mode = mode1;
						  break;
					  }
				  }

			  break;

			  case LOCKED:
				  blueButton = 0;

				  if (debounce_counter > DEBOUNCE_INTERVAL) {
					  debounce_state = RELEASED; // RELEASE after time-out
					  debounce_counter = 0;
				  }

				  else {
					  ++debounce_counter; // still LOCKED, increase counter
				  }
			break;
		}


		switch(got_adc/1023){
		case 0:
			TIM3 -> PSC = 10000;
			break;

		case 1:
			TIM3 -> PSC = 30000;
			break;

		case 2:
			TIM3 -> PSC = 45000;
			break;

		case 3:
			TIM3 -> PSC = 65000;
			break;

		}
		//Printing values of the ADC
		//printf("DMA IT: Got %4ld at Loop = %d\n", got_adc, ++loop);
	}

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim -> Instance == TIM3){

		if(mode == mode1){
			HAL_GPIO_WritePin (LD3_GPIO_Port, LED[LEDCounter], GPIO_PIN_RESET);

			if ((int8_t)auchSpiRxBuf[0] > 0){
				LEDCounter--;
			}

			else {
				LEDCounter++;
			}

			if(LEDCounter > 3){
				LEDCounter = 0;
			}

			if(LEDCounter < 0){
				LEDCounter = 3;
			}

			HAL_GPIO_TogglePin (LD3_GPIO_Port, LED[LEDCounter]);
		}

		if(mode == mode2){
			HAL_GPIO_WritePin(LD3_GPIO_Port, LED2[LEDCounter], GPIO_PIN_RESET);

			if ((int8_t) auchSpiRxBuf[0] > 0) {
				LEDCounter--;
			}

			else {
				LEDCounter++;
			}

			if (LEDCounter > 3) {
				LEDCounter = 0;
			}

			if (LEDCounter < 0) {
				LEDCounter = 3;
			}

			HAL_GPIO_TogglePin(LD3_GPIO_Port, LED2[LEDCounter]);
		}
	}
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
	if(hadc == &hadc1){
		got_adc = ADCValue;
	}
}

#endif
