/*
 * Ass-5-Q1.c
 *
 *  Created on: Apr 22, 2022
 *      Author: minnieb
 */

#include "Ass-5.h"

#if DO_QUESTION == 1

void Ass_5_main (void){

	HAL_TIM_Base_Start_IT(&htim3);

	while (1){

	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	HAL_GPIO_TogglePin (LD6_GPIO_Port, LD6_Pin);
	//HAL_Delay (TOGGLE_DELAY);

}

#endif
